public class IceSpell extends Spell {
    //Variables
    double range_reduction_percentage, icespell_damage_dealt;

    //Functions
    //Constructor
    public IceSpell(String living_name, String spell_name) {
        super(living_name, spell_name);
        this.maxDamage = this.minDamage + RandomUtil.randomStat(10, 25);
        this.damageRange = new double[] { this.minDamage, this.maxDamage };
        this.range_reduction_percentage = RandomUtil.randomStat(0.2, 0.5);        // 20%–50% reduction
        this.icespell_damage_dealt = RandomUtil.randomStat(this.minDamage, this.maxDamage);
    }
    // Ice Spell debuff for couple rounds (check monster class)
    public void reduce_enemy_damage_range(Monster enemy, int rounds) {
        // Save original damage range only if there is not already active effect
        if (enemy.iceRoundsLeft == 0) {
            enemy.originalMinDamage = enemy.getMinDamage();
            enemy.originalMaxDamage = enemy.getMaxDamage();
        }
        double newMin = enemy.getMinDamage() * (1 - range_reduction_percentage);
        double newMax = enemy.getMaxDamage() * (1 - range_reduction_percentage);
        enemy.setMinDamage(newMin);
        enemy.setMaxDamage(newMax);
        enemy.iceRoundsLeft = rounds;

        System.out.println("IceSpell has reduced enemy's damage range by " + (int)(range_reduction_percentage * 100) + "% for " + rounds + " rounds.");
    }
}