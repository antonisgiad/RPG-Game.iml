public class Paladin extends Hero{
    //Variables
    double increased_paladin_strength, increased_paladin_dexterity;

    //Functions
    //Constructor
    public Paladin(String living_name) {
        super(living_name);
        this.increased_paladin_strength = RandomUtil.randomStat(12, 25);   // Fully random
        this.increased_paladin_dexterity = RandomUtil.randomStat(12, 25);  // Fully random
    }
}
