public class LightningSpell extends Spell {
    //Variables
    double lightningspell_damage_dealt, range_reduction_percentage;

    //Functions
    //Constructor
    public LightningSpell(String living_name, String spell_name) {
        super(living_name, spell_name);
        this.maxDamage = this.minDamage + RandomUtil.randomStat(10, 25);
        this.damageRange = new double[] { this.minDamage, this.maxDamage };
        this.lightningspell_damage_dealt = RandomUtil.randomStat(this.minDamage, this.maxDamage);
        this.range_reduction_percentage = RandomUtil.randomStat(0.1, 0.4); // 10%–40% reduction
    }
    // Lightning Spell debuff for couple rounds (check monster class)
    public void reduce_enemy_dodge_chance(Monster enemy, int rounds, double dodgeReductionPercent) {
        // Save original dodge chance only if there is not already active effect
        if (enemy.lightningRoundsLeft == 0) {
            enemy.originalDodgeChance = enemy.getDodgeChance();
        }
        double newDodgeChance = enemy.getDodgeChance() * (1 - dodgeReductionPercent);
        enemy.setDodgeChance(newDodgeChance);
        enemy.lightningRoundsLeft = rounds;

        System.out.println("LightningSpell has reduced enemy's dodge chance by " + (int)(dodgeReductionPercent * 100) + "% for " + rounds + " rounds.");
    }

    public void reduce_chance_of_missed_attack(Monster enemy) {
        // Calculate new chance
        double newChance = enemy.getDodgeChance() * (1 - range_reduction_percentage);
        System.out.println("LightningSpell has reduced enemy's chance of missed attack by " + (int)(range_reduction_percentage * 100) + "%.");
    }
}