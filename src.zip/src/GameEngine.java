import java.util.Scanner;

public class GameEngine {
    private Grid grid;
    private Player player;
    private Scanner scanner;

    public void start() {
        scanner = new Scanner(System.in);
        initializeGrid();
        initializePlayerAndHeroes();
        offerStartingMarketOptions();
        mainGameLoop();
    }

    private void initializeGrid() {
        System.out.print("Enter grid rows: ");
        int rows = Integer.parseInt(scanner.nextLine());
        System.out.print("Enter grid columns: ");
        int cols = Integer.parseInt(scanner.nextLine());
        grid = new Grid(rows, cols);
    }

    private void initializePlayerAndHeroes() {
        System.out.print("Enter your player name: ");
        String playerName = scanner.nextLine();
        int startRow = 0, startCol = 0;
        player = new Player(playerName, startRow, startCol);

        int numHeroes = 0;
        while (true) {
            System.out.print("How many heroes in your team? (1–3): ");
            try {
                numHeroes = Integer.parseInt(scanner.nextLine());
                if (numHeroes >= 1 && numHeroes <= 3) {
                    break;
                } else {
                    System.out.println("You must choose between 1 and 3 heroes. Try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number between 1 and 3.");
            }
        }

        for (int i = 1; i <= numHeroes; i++) {
            System.out.print("Enter name for Hero " + i + ": ");
            String heroName = scanner.nextLine();
            System.out.println("Choose hero type for " + heroName + ": 1) Warrior 2) Sorcerer 3) Paladin");
            int type = Integer.parseInt(scanner.nextLine());
            Hero hero;
            switch (type) {
                case 1: hero = new Warrior(heroName); break;
                case 2: hero = new Sorcerer(heroName); break;
                case 3: hero = new Paladin(heroName); break;
                default: hero = new Warrior(heroName);
            }
            player.addHero(hero);
        }
    }

    private void offerStartingMarketOptions() {
        System.out.println("Welcome to the starting market!");
        System.out.println("Choose your starting bonus: 1) Extra Gold 2) Starter Pack (Potion, Weapon, Armor)");
        int choice = Integer.parseInt(scanner.nextLine());
        if (choice == 1) {
            player.addGold(100); // Example bonus
            System.out.println("You received 100 extra gold!");
        } else {
            player.addItem(new Potion("Starter Potion"));
            player.addItem(new Weapon("Starter Sword"));
            player.addItem(new Armor("Starter Armor"));
            System.out.println("You received a starter pack: Potion, Sword, Armor!");
        }
    }

    private void mainGameLoop() {
        System.out.println("Game starts!");
        grid.displayGrid(player); // Show grid with player at the start
        while (true) {
            player.displayStatus();
            System.out.print("Enter move (up/down/left/right) or 'exit': ");
            String input = scanner.nextLine();
            if (input.equalsIgnoreCase("exit")) break;
            if (player.move(input, grid)) {
                grid.displayGrid(player); // Show grid after every move
                player.performCellAction(grid);
            }
        }
        scanner.close();
        System.out.println("Game Over. Thanks for playing!");
    }

}