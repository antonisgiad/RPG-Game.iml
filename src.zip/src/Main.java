import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Create and start the game engine
        GameEngine game = new GameEngine();
        game.start();
    }
}