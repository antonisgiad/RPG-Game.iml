public class Item {
    //Variables
    String item_name;
    double item_market_price;
    int item_min_level;

    //Functions
    //Constructor
    public Item(String item_name) {
        this.item_name = item_name;
        this.item_market_price = RandomUtil.randomStat(10, 100); // Price between 10–100
        this.item_min_level = RandomUtil.randomLevel(1, 5);      // Level between 1–5
    }

    //Getters
    public String getItem_name() {
        return item_name;
    }

    public double getItem_market_price() {
        return item_market_price;
    }

    public int getItem_min_level() {
        return item_min_level;
    }
}
