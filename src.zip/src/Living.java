public class Living {
    //Variables
    String living_name;
    int living_level;
    double healthPower;
    boolean isPassedOut;

    //Functions
    //Constructor
    public Living(String living_name) {
        this.living_name = living_name;
        this.living_level = RandomUtil.randomLevel(1, 3);        // e.g., level 1–3
        this.healthPower = RandomUtil.randomStat(60, 120);       // e.g., health 60–120
        this.isPassedOut = false;
    }
    //Check if Living has passed out
    public void passed_out(){
        if (healthPower <= 0){
            isPassedOut = true;
            System.out.println(living_name + " has passed out...");
        }
    }
    //Getters & Setters
    public String getLiving_name() {
        return living_name;
    }

    public void setLiving_name(String living_name) {
        this.living_name = living_name;
    }

    public int getLiving_level() {
        return living_level;
    }

    public void setLiving_level(int living_level) {
        this.living_level = living_level;
    }

    public double getHealthPower() {
        return healthPower;
    }

    public void setHealthPower(double healthPower) {
        this.healthPower = healthPower;
    }

    public boolean isPassedOut() {
        return isPassedOut;
    }

    public void setPassedOut(boolean passedOut) {
        isPassedOut = passedOut;
    }
}