public class Spirit extends Monster{
    //Variables
    double increased_dodgeChance;

    //Functions
    //Constructor
    public Spirit(String living_name) {
        super(living_name);
        // Spirits are known for high dodge and magical attacks
        this.increased_dodgeChance = RandomUtil.randomStat(0.15, 0.40); // Higher dodge for Spirits
    }
}