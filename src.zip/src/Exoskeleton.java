public class Exoskeleton extends Monster{
    //Variables
    double increased_defense;

    //Functions
    //Constructor
    public Exoskeleton(String living_name) {
        super(living_name);
        this.increased_defense = RandomUtil.randomStat(10, 25);     // Fully random increased defense
    }
}