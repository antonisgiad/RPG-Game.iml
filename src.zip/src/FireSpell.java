public class FireSpell extends Spell {
    //Variables
    double firespell_damage_dealt, range_reduction_percentage;

    //Functions
    //Constructor
    public FireSpell(String living_name, String spell_name) {
        super(living_name, spell_name);
        this.maxDamage = this.minDamage + RandomUtil.randomStat(10, 25);
        this.damageRange = new double[] { this.minDamage, this.maxDamage };
        this.firespell_damage_dealt = RandomUtil.randomStat(this.minDamage, this.maxDamage);
        this.range_reduction_percentage = RandomUtil.randomStat(0.1, 0.4); // 10%–40% reduction
    }
    // Fire Spell debuff for couple rounds (check monster class)
    public void reduce_enemy_defense(Monster enemy, int rounds, double defenseReductionPercent) {
        // Save original defense only if there is not already active effect
        if (enemy.fireRoundsLeft == 0) {
            enemy.originalDefense = enemy.getDefense();
        }
        double newDefense = enemy.getDefense() * (1 - defenseReductionPercent);
        enemy.setDefense(newDefense);
        enemy.fireRoundsLeft = rounds;

        System.out.println("FireSpell has reduced enemy's defense by " + (int)(defenseReductionPercent * 100) + "% for " + rounds + " rounds.");
    }
}