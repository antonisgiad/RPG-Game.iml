public class Armor extends Item{
    //Variables
    double reduced_damage;

    //Functions
    //Constructor
    public Armor(String item_name) {
        super(item_name);
        this.reduced_damage = RandomUtil.randomStat(5, 30); // Reduces damage by 5–30
    }

    public double reduce_monster_damage_taken(Monster monster) {
        double[] damageRange = monster.getDamageRange();
        // Choose random damage from damage range
        double incomingDamage = damageRange[0] + Math.random() * (damageRange[1] - damageRange[0]);
        double reducedDamage = incomingDamage - reduced_damage;
        if (reducedDamage < 0) {
            reducedDamage = 0;
        }
        return reducedDamage;
    }
}