public class Weapon extends Item{
    //Variables
    double weapon_damage;
    int hands;

    //Functions
    //Constructor
    public Weapon(String item_name) {
        super(item_name);
        this.weapon_damage = RandomUtil.randomStat(15, 60); // Damage between 15–60
        this.hands = RandomUtil.randomLevel(1, 2);          // 1 or 2 hands
    }

    //Getters & Setters
    public double getWeapon_damage() {
        return weapon_damage;
    }

    public void setWeapon_damage(double weapon_damage) {
        this.weapon_damage = weapon_damage;
    }

    public void setHands(int hands) {
        this.hands = hands;
    }

    //How many hands used
    public int hands_needed(){
        if (hands == 1) {
            System.out.println("This Weapon requires " + hands + " hand.");
        }
        else if (hands == 2) {
            System.out.println("This Weapon requires " + hands + " hands.");
        }
        return hands;
    }
}
