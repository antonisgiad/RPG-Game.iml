public class Sorcerer extends Hero {
    //Variables
    double increased_sorcerer_dexterity, increased_sorcerer_agility;

    //Functions
    //Constructor
    public Sorcerer(String living_name) {
        super(living_name);
        this.increased_sorcerer_agility = RandomUtil.randomStat(20, 40); // Fully random
        this.increased_sorcerer_dexterity = RandomUtil.randomStat(15, 30);  // Fully random
    }
}