public class Dragon extends Monster{
    //Variables
    double increased_minDamage, increased_maxDamage;
    double[] increased_damageRange = {increased_minDamage, increased_maxDamage};

    //Functions
    //Constructor
    public Dragon(String living_name) {
        super(living_name);
        // Randomly generate increased min/max damage for the Dragon
        this.increased_minDamage = RandomUtil.randomStat(15, 35);
        this.increased_maxDamage = RandomUtil.randomStat(25, 50);
        this.increased_damageRange = new double[] {increased_minDamage, increased_maxDamage};
    }
}